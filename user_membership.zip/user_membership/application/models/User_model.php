<?php
class User_model extends CI_Model {
    
    //  Save user data and activation code to the database
    public function register_user($data) {
       $this->db->insert('users', $data);
    }

    // Status change after email verification
    public function activate_user($token) {
        $this->db->where('activation_token', $token);
        $this->db->update('users', ['verification_status' => 1]);
    }

    // login user information
    public function login_user($email, $password) {
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $this->db->where('verification_status', '1');
        $query = $this->db->get('users');
        return $query->row();
    }

    // Update user profile
    public function update_user($id, $data) {
        $this->db->where('user_id', $id);
        $this->db->update('users', $data);
    }

    // Fetch userdata for display on profile 
    public function fetch_data($id){
        $this->db->select('username,first_name,last_name,email,password');
        $this->db->where('user_id', $id);
        $query = $this->db->get('users'); 
        return $query->row();
    }
}
?>
