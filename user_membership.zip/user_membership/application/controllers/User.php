<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct() {
        parent::__construct();
        $this->load->model('user_model'); //load user model 
    }


	public function index()
	{
        // User not login display home page
        if($this->session->userdata('user_id')==''){
            $this->load->view('home');
        }
        // User login redirect dashboard
        else if($this->session->userdata('user_id')!==''){
            redirect('user/dashboard');
        }	
	}

   
	public function register() {
        // Register user information
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = array(
                'username' => $this->input->post('username'),
                'email' => $this->input->post('email'),
                'first_name' => $this->input->post('first_name'),
                'last_name' => $this->input->post('last_name'),
                'password' => $this->input->post('password'),
                'verification_status' => 0,
                // Generate a unique activation code
                'activation_token' => bin2hex(random_bytes(16))
            );

            // Save user data and activation code to the database
            $this->user_model->register_user($data);
            
            // Send activation email
            $this->email->from('ankitthakur8698@gmail.com', 'Security');
            $this->email->to($data['email']);
            $this->email->subject('Account Activation');
            $this->email->message('Please click the link below to activate your account: ' . base_url('user/activate/' . $data['activation_token']));
            $this->email->send();

            // Redirect to a page displaying a message to check the email inbox
                if($this->db->affected_rows() > 0)
                {
                    $this->session->set_flashdata('success','Registration successful. Please check your email for activation instructions.');
                }
                else{
                    $this->session->set_flashdata('worng','Registration not successful. Please try again!!!');
                }
                redirect('user'); 
        }  
    }

    public function activate($token) {
        // Check if the activation code exists in the database
        // Activate the user account
        $this->user_model->activate_user($token);

        // User verify display message
        if($this->db->affected_rows() > 0)
        {
            $this->session->set_flashdata('success','Account activated successfully. You can now login.');
        }
        else{
            $this->session->set_flashdata('worng','Account not activated successfully. Please verify the account!!!');
        }
        redirect('user'); 
    }

    
    public function login() {
        // Handle login form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $email = $this->input->post('email');
            $password = $this->input->post('password');

            $user = $this->user_model->login_user($email, $password);
            // Check if the user is verified than display message
            if ($user) {
                $this->session->set_userdata('user_id', $user->user_id);
                $this->session->set_flashdata('success','Welcome to Dahsboard');

                redirect('user/dashboard');
            }
            else{
                $this->session->set_flashdata('worng','Account not activated successfully. Please verify the account!!!');
                redirect('user');
            }
           
        }
    }

    public function dashboard(){
        //After login user go to the dashboard
        $id = $this->session->userdata('user_id');
        //Fetching the user data for dispaying on profile box
        $user = $this->user_model->fetch_data($id);
        $data['user'] = $user;
        $this->load->view('dashboard',$data);
    }

    public function profile(){
        // User not login redirect to home page for login
        if (!$this->session->userdata('user_id')) {
            redirect('user');
        }
        // Handle profile update form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = array(
                'email' => $this->input->post('email'),
                'first_name' => $this->input->post('first_name'),
                'last_name' => $this->input->post('last_name'),
                'password' => $this->input->post('password')
            );

            // Submitting the data for update
            $this->user_model->update_user($this->session->userdata('user_id'), $data);

            // Data update show message
            if($this->db->affected_rows() > 0){
                $this->session->set_flashdata('success','Profile updated successfully.');
            }
            redirect('user/dashboard');
        }
    }

    public function logout(){

        // Perform logout actions, such as destroying the session
        if($this->session->unset_userdata('user_id'))
        {
            $this->session->set_flashdata('info','You are logout , Please Login.');
        }
        // Redirect to the homepage
        redirect('user');
    }
  
}
