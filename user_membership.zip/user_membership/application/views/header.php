<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>User Membership</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Bootstrap icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet"
        type="text/css" />
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet"
        type="text/css" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="<?=base_url()?>assets/css/styles.css" rel="stylesheet" />

    <!-- Toster -->
    <link rel="stylesheet" href="<?=base_url();?>assets/all.css">
    <link rel="stylesheet" href="<?=base_url();?>assets/toast/toast.min.css">
    <script src="<?=base_url();?>assets/toast/jqm.js"></script>
    <script src="<?=base_url();?>assets/toast/toast.js"></script>
</head>
    <body>
        <!-- Navigation-->
        <nav class="navbar navbar-light bg-light static-top">
            <div class="container">
                <a class="navbar-brand" href="#!">Start Bootstrap</a>

                <div class="nav-link">
                    <!-- Button trigger modal -->
                    <!-- Button  login/logout according to user id -->
                    <?php if($this->session->userdata('user_id')==''){ ?>
                            <a href="#signup" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#Login">Login</a>
                            <a class="btn btn-primary" href="#signup" data-bs-toggle="modal" data-bs-target="#Signup">Sign Up</a>
                       <?php }else if($this->session->userdata('user_id')!==''){  ?>
                        <a class='btn btn-secondary' href="<?=base_url()?>user/logout">Logout</a>
                     <?php }?>
                </div>

            </div>
        </nav>
