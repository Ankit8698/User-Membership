</footer>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="<?=base_url()?>assets/js/form-validattion.js"></script>
    <script src="<?=base_url()?>assets/js/scripts.js"></script>
    <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
    <!-- * *                               SB Forms JS                               * *-->
    <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
    <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
    <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

    <!-- Toster message -->
    <script type="text/javascript">
        <?php if($this->session->flashdata('success')){ ?>
            toastr.success("<?php echo $this->session->flashdata('success'); ?>");
        <?php }
            else if($this->session->flashdata('worng'))
            { ?>
            toastr.error("<?php echo $this->session->flashdata('worng'); ?>");
        <?php }
        else if($this->session->flashdata('warning')){ 
            ?>
            toastr.warning("<?php echo $this->session->flashdata('warning'); ?>");
        <?php }
        else if($this->session->flashdata('info')){
            ?>
            toastr.info("<?php echo $this->session->flashdata('info'); ?>");
        <?php } ?>
        <?php
        $this->session->unset_userdata ( 'success' ); ?>
        
        <?php
        $this->session->unset_userdata ( 'worng' ); ?>

    </script>

<!-- Edit profile form script -->
<script>
    document.getElementById("dropdownButton").addEventListener("click", function() {
      document.querySelector(".dropdown-menu").classList.toggle("show");
    });
  </script>
</body>

</html>